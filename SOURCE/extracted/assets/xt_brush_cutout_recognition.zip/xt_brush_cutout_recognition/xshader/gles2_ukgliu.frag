precision highp float;
varying vec2 v_texcoord;
uniform sampler2D strokeTexture;
uniform vec3 colorRGB;
uniform float colorA;

void main()
{
    vec4 simpleMask = texture2D(strokeTexture, v_texcoord);
    if(simpleMask.r == simpleMask.g && simpleMask.g == simpleMask.b)
    {
        simpleMask.a = simpleMask.r;
    }
    gl_FragColor = vec4(colorRGB, simpleMask.a);
    gl_FragColor.rgb *= gl_FragColor.a;
}
