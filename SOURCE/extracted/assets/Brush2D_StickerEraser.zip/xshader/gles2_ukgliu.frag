precision highp float;
varying vec2 v_texcoord;
uniform sampler2D strokeTexture;
uniform float colorA;

void main()
{
    vec4 simpleMask = texture2D(strokeTexture, v_texcoord);
    gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0) * colorA * simpleMask.x;
}
