local initFlag = true
local inputColor = 1.0

EventHandles =
{
    handleComposerUpdateNodeEvent = function (this, path, tag, percentage)
        local feature = this:getFeature("FaceMakeupV2_byTool")
        local _feature = EffectSdk.castFaceMakeupV2Feature(feature)
        if (not feature) or (not _feature) then
            print("FaceMakeupV2_byTool is not exist")
            return false
        end
        if tag == "XTMakeupEyeLash" then
            -- _feature:setIntensity("eye_part_faceu+2991",percentage)
            -- _feature:setIntensity("eye_part_faceu+2992",percentage)
            _feature:setIntensity("eye_part_faceu+2985",percentage)
            print("yzh_jiemao_intensity:", percentage)
        end
        _feature:setUniform("eye_part_faceu2985","inputColor",inputColor)
        -- _feature:setUniform("eye_part_faceu2992","inputColor",inputColor)
        -- _feature:setUniform("jiemao_faceu2990","inputColor",inputColor)--标志位是否开启颜色输入模式
        if tag == "R" then
            _feature:setUniform("eye_part_faceu2985","colorR",percentage)
            -- _feature:setUniform("eye_part_faceu2992","colorR",percentage)
            -- _feature:setUniform("jiemao_faceu2990","colorR",percentage)
            print("yzh_jiemao_R:", percentage)
        end

        if tag == "G" then
            _feature:setUniform("eye_part_faceu2985","colorG",percentage)
            -- _feature:setUniform("eye_part_faceu2992","colorG",percentage)
            -- _feature:setUniform("jiemao_faceu2990","colorG",percentage)
            print("yzh_jiemao_G:", percentage)
        end

        if tag == "B" then
            _feature:setUniform("eye_part_faceu2985","colorB",percentage)
            -- _feature:setUniform("eye_part_faceu2992","colorB",percentage)
            -- _feature:setUniform("jiemao_faceu2990","colorB",percentage)
            print("yzh_jiemao_B:", percentage)
        end

    end,
}
