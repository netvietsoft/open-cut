precision highp float;
varying vec2 v_texcoord;
uniform sampler2D shapeTexture;
uniform float colorA;
uniform float opacity;
void main(){
    gl_FragColor = texture2D(shapeTexture, v_texcoord) * opacity * colorA * colorA;
}
