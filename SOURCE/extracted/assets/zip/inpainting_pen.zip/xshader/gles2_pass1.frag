precision highp float;
varying vec2 v_texcoord;
uniform sampler2D strokeTexture;
uniform sampler2D layerTexture;
uniform vec3 colorRGB;
uniform float colorA;
void main(){
    vec4 simpleMask = texture2D(strokeTexture, v_texcoord);
    vec4 layerColor = texture2D(layerTexture, v_texcoord);
    //gl_FragColor = vec4(colorRGB, colorA * simpleMask.x);

    //float _colorA = 0.6;
    //float _colorAMask = _colorA * simpleMask.x;
    float _colorAMask = colorA * simpleMask.x;

    // mix
    //gl_FragColor = mix(layerColor, vec4(colorRGB, 1.0), _colorAMask);

    // max
    vec4 strokeColor = vec4(colorRGB * _colorAMask, _colorAMask);
    gl_FragColor = max(layerColor, strokeColor);
}
