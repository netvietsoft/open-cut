precision highp float;
varying vec2 uv0;
varying vec2 uv1;
uniform float uniAlpha;
uniform sampler2D inputImageTexture;
uniform sampler2D inputImageTexture2;

vec4 lm_take_effect_filter(sampler2D filterTex,vec4 inputColor,float uniAlpha)
{
  highp vec4 textureColor= inputColor;	
  highp float blueColor=textureColor.b*63.;
  
  highp vec2 quad1;
  quad1.y=0.;
  quad1.x=floor(blueColor) / 64.;
  
  highp vec2 quad2;
  quad2.y=0.;
  quad2.x=ceil(blueColor) / 64.;
  
  highp vec2 texPos1;
  texPos1.x=quad1.x+(textureColor.r * 63. / 4096.) + 0.5/4096.;
  texPos1.y=quad1.y+(textureColor.g * 63. / 64.) + 0.5/64.;
  
  highp vec2 texPos2;
  texPos2.x=quad2.x+(textureColor.r * 63. / 4096.) + 0.5/4096.;
  texPos2.y=quad2.y+(textureColor.g * 63. / 64.) + 0.5/64.;
  
  vec4 newColor1=texture2D(filterTex,texPos1);
  vec4 newColor2=texture2D(filterTex,texPos2);
  vec4 newColor=mix(newColor1,newColor2,fract(blueColor));
  newColor = mix(textureColor,vec4(newColor.rgb,textureColor.w),uniAlpha);

  return newColor;
}

void main()
{
    vec4 curColor = texture2D(inputImageTexture,uv0);
    vec4 resultColor = lm_take_effect_filter(inputImageTexture2,curColor,uniAlpha);
    resultColor.rgb = mix(curColor.rgb, resultColor.rgb, curColor.a);
    resultColor.a = curColor.a;
    gl_FragColor = resultColor;
}