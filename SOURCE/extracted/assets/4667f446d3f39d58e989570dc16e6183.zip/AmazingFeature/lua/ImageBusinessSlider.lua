--write by editor  EffectSDK:12.7.0 EngineVersion:12.7.0 EditorBuildTime:Nov__2_2022_09_58_45
--sliderVersion: 20210901  Lua generation date: Fri Dec  2 17:55:06 2022


local exports = exports or {}
local ImageBusinessSlider = ImageBusinessSlider or {}
ImageBusinessSlider.__index = ImageBusinessSlider


function ImageBusinessSlider.new(construct, ...)
    local self = setmetatable({}, ImageBusinessSlider)
    if construct and ImageBusinessSlider.constructor then
        ImageBusinessSlider.constructor(self, ...)
    end
    return self
end


local function remap(x, a, b)
    return x * (b - a) + a
end


function ImageBusinessSlider:onStart(sys)
    self.SeekModeScriptMaterial0 = sys.scene:findEntityBy("SeekModeScript"):getComponent("Renderer").material
end


function ImageBusinessSlider:onEvent(sys,event)
    if event.args:get(0) == "Internal_Filter" then
        local intensity = event.args:get(2)
        self.SeekModeScriptMaterial0["uniAlpha"] = remap(intensity,0,1)
    end
end


exports.ImageBusinessSlider = ImageBusinessSlider
return exports