{
    "algorithm": "tccartoon",
    "app_id": 2,
    "max_len": 2048,
    "support_format": ["image/jpg"],
    "api":"/media/api/pic/afr/",
    "effect": {
        "Link": [
            {
                "type": "playfunction"
            }
        ],
        "requirement": {
            
        }
    },
    "name": "play function",
    "version": "1.1"
}