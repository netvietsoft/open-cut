#version 300 es
layout(location = 0) in vec3 attPosition;
layout(location = 1) in vec2 attUV;
out vec2 v_TextureCoordinates;

uniform mat4 uTRS;

void main()
{
    gl_Position = uTRS * vec4(attPosition, 1.0);
    v_TextureCoordinates = (gl_Position.xy + 1.0) * 0.5;
}
