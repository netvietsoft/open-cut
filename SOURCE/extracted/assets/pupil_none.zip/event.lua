local initFlag = true

EventHandles =
{
    handleComposerUpdateNodeEvent = function (this, path, tag, percentage)
        local feature = this:getFeature("FaceMakeupV2_byTool")
        local _feature = EffectSdk.castFaceMakeupV2Feature(feature)
        if (not feature) or (not _feature) then
            print("FaceMakeupV2_byTool is not exist")
            return false
        end
        if tag == "XTMakeupPupil" then
            _feature:setIntensity("pupil_faceu+2993",math.min(1.0,percentage*1.4))
        end
    end,
}
