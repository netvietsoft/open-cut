local initFlag = true
local inputColor = 1.0

EventHandles =
{    
    handleComposerUpdateNodeEvent = function (this, path, tag, percentage)
        local feature = this:getFeature("FaceMakeupV2_byTool")
        local _feature = EffectSdk.castFaceMakeupV2Feature(feature)
        if (not feature) or (not _feature) then
            print("FaceMakeupV2_byTool is not exist")
            return false
        end
        if tag == "XTMakeupEyeBrow" then
            _feature:setIntensity("brow_faceu+2996",percentage)
        end
        
        _feature:setUniform("brow_faceu2996","inputColor",inputColor)--标志位是否开启颜色输入模式
        if tag == "R" then
            _feature:setUniform("brow_faceu2996","colorR",percentage)
        end

        if tag == "G" then
            _feature:setUniform("brow_faceu2996","colorG",percentage)
        end

        if tag == "B" then
            _feature:setUniform("brow_faceu2996","colorB",percentage)
        end
    end,
}
