attribute vec2 attPosition;
attribute vec2 attPosition1;
attribute vec2 attUV;
attribute float attOpacity;

varying vec2 texCoord;
varying vec2 texCoord1;
varying vec2 sucaiTexCoord;
varying float varOpacity;

uniform mat4 uMVPMatrix;
uniform mat4 uSTMatrix;

void main(void)
{
    gl_Position = uMVPMatrix * vec4(attPosition.xy, 0.0, 1.0);
    texCoord = 0.5 * gl_Position.xy + 0.5;
    
    vec4 coord = uMVPMatrix * vec4(attPosition1.xy, 0.0, 1.0);
    texCoord1 = 0.5 * coord.xy + 0.5;
    
    coord = uSTMatrix * vec4(attUV.xy, 0.0, 1.0);
    sucaiTexCoord = vec2(coord.x, 1.0 - coord.y);
    varOpacity = attOpacity;
}