precision highp float;
varying vec2 v_texcoord;
varying vec4 v_opacity;
uniform float hardness;
uniform float strokeSize;

void main()
{
    float dist = distance(v_texcoord, vec2(0.5));
    float shapeMask = 1.0 - smoothstep(0.5 * hardness - 3.0 / strokeSize, 0.5, dist);
    gl_FragColor = vec4(shapeMask * v_opacity.rgb,1.0);
}
