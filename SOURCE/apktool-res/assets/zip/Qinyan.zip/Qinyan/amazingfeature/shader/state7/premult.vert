precision highp float;

attribute vec4 position;
attribute vec2 uv;

varying vec2 textureCoordinate; 
// varying vec2 textureCoordinate2; 
// varying vec2 textureCoordinate3; 

varying vec4 textureShift_1; 
varying vec4 textureShift_2; 
varying vec4 textureShift_3; 
varying vec4 textureShift_4; 

uniform highp float widthOffset; //0.0018519 即 1/w
uniform highp float heightOffset; //0.0010417 即1/h

uniform mat4 u_MVP;
void main(void)
{
    // gl_Position = u_MVP * position;
    gl_Position = sign(vec4(position.xy, 0.0, 1.0));
    textureCoordinate = uv.st; //4个顶点
	// textureCoordinate2 = uv.st; 
	// textureCoordinate3 = uv.st; 

    textureShift_1 = vec4(uv.st + vec2(-widthOffset,0.0),uv.st + vec2(widthOffset,0.0));
    textureShift_2 = vec4(uv.st + vec2(0.0,-heightOffset),uv.st + vec2(0.0,heightOffset));
    textureShift_3 = vec4(uv.st + vec2(widthOffset,heightOffset),uv.st + vec2(-widthOffset,-heightOffset));
    textureShift_4 = vec4(uv.st + vec2(-widthOffset,heightOffset),uv.st + vec2(widthOffset,-heightOffset));
}
