precision highp float;

attribute vec4 position;
attribute vec2 uv;

varying vec2 textureCoordinate; 
varying vec2 textureCoordinate2; 
uniform mat4 u_MVP;

void main(void)
{
    // gl_Position = u_MVP * position;
    gl_Position = sign(vec4(position.xy, 0.0, 1.0));
    textureCoordinate = uv.st; 
	textureCoordinate2 = uv.st;
}
