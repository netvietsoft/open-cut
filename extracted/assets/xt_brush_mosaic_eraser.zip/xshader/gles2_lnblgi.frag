precision highp float;
varying vec2 v_texcoord;
uniform sampler2D strokeTexture;
uniform sampler2D layerTexture;

void main(){
    vec4 simpleMask = texture2D(strokeTexture, v_texcoord);
    vec4 layerColor = texture2D(layerTexture, v_texcoord);
    gl_FragColor = layerColor * (1.0 - smoothstep(0.1, 1.0, simpleMask.r));
}
