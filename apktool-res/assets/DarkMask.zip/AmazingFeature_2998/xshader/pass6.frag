precision highp float;
varying vec2 uv0;
varying vec2 uv1;
uniform float uniAlpha;
uniform sampler2D inputImageTexture;

void main()
{
    vec4 curColor = texture2D(inputImageTexture,uv0);
    vec4 resultColor = mix(curColor, curColor*0.5, uniAlpha);
    resultColor.rgb = mix(curColor.rgb, resultColor.rgb, curColor.a);
    resultColor.a = curColor.a;
    gl_FragColor = resultColor;
}