precision highp float;
varying vec2 v_texcoord;
uniform sampler2D stampTexture;
uniform float colorA;
void main(){
    vec4 stampColor = texture2D(stampTexture, v_texcoord);
    gl_FragColor = stampColor * colorA;
}